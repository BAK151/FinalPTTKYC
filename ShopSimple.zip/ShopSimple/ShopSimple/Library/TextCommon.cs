﻿namespace ShopSimple.Library
{
    public class TextCommon
    {
        public static string Edit = "Sửa";
        public static string Save = "Lưu";
        public static string Delete = "Xoá";
        public static string Cancel = "Huỷ";
    }
}
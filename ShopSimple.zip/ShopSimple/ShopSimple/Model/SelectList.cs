﻿namespace ShopSimple.Model
{
    public class SelectList
    {
        private string _display;
        private string _value;

        public string Display { get => _display; set => _display = value; }
        public string Value { get => _value; set => _value = value; }
    }
}